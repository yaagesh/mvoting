package in.farmagain.voteinlive;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * An example full-screen activity that shows and hides the system UI (i.e.
 * status bar and navigation/system bar) with user interaction.
 */
public class FullscreenActivity extends AppCompatActivity {

   private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_fullscreen);

        FullscreenActivity.this.getSupportActionBar().hide();
        getWindow().setStatusBarColor(Color.parseColor("#c0c0c0"));

        webView = (WebView) findViewById(R.id.web);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setUseWideViewPort(true);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        webView.loadUrl("http://votein.tk");

        ProgressBar progressBar = (ProgressBar) findViewById(R.id.progressBar);

        final RelativeLayout nodata = (RelativeLayout) findViewById(R.id.nodata);
        nodata.setVisibility(View.GONE);

        try {
            AsyncTask.execute(new Runnable() {
                @Override
                public void run() {
                    URL url = null;
                    try {
                        url = new URL("http://votein.tk");
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                    }
                    HttpURLConnection httpURLConnection = null;
                    try {
                        httpURLConnection = (HttpURLConnection) url.openConnection();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    int code = 0;
                    try {
                        code = httpURLConnection.getResponseCode();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    if (code != 200){
                        final int finalCode = code;
                        FullscreenActivity.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (finalCode != 200){
                                    nodata.setVisibility(View.VISIBLE);
                                }
                            }
                        });
                        //nodata.setVisibility(View.VISIBLE);
                    }

                }
            });
        } catch (Exception ignored){

        }

        progressBar.setVisibility(View.GONE);

    }



}
