package india.vote.votein;

import android.content.Intent;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.util.concurrent.TimeUnit;

public class CountDownActivity extends AppCompatActivity {

    private TextView countDown;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_count_down);

        countDown = (TextView) findViewById(R.id.count_down);

        new CountDownTimer(30000, 100) {

            public void onTick(long millisUntilFinished) {
                String hms = String.format("%02d:%02d",
                        TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished) % TimeUnit.HOURS.toMinutes(1),
                        TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) % TimeUnit.MINUTES.toSeconds(1));
                countDown.setText(hms);
            }

            public void onFinish() {
                countDown.setText("00:00");
                Intent intent = new Intent(CountDownActivity.this, VotingActivity.class);
                startActivity(intent);
                finish();
            }
        }.start();

    }
}
