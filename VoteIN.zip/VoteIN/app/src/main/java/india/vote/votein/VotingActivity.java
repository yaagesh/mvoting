package india.vote.votein;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

import static android.app.AlertDialog.*;

public class VotingActivity extends AppCompatActivity {

    private int checkedItem;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_voting);

        Button done = (Button) findViewById(R.id.doneButton);
        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (validate()){
                    long i = (Long.parseLong(DetailStore.getAadhaarid()))+ 543210543210L;
                    stamp = ""+i;

                    new getUserDet().execute("");
                }
            }
        });

        RadioGroup rGroup = (RadioGroup) findViewById(R.id.radiogroup);
// This will get the radiobutton in the radiogroup that is checked
        RadioButton checkedRadioButton = (RadioButton)rGroup.findViewById(rGroup.getCheckedRadioButtonId());

        rGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
        {
            public void onCheckedChanged(RadioGroup group, int checkedId)
            {
                // This will get the radiobutton that has changed in its check state
                RadioButton checkedRadioButton = (RadioButton)group.findViewById(checkedId);
                // This puts the value (true/false) into the variable
                boolean isChecked = checkedRadioButton.isChecked();
                // If the radiobutton that has changed in check state is now checked...
                if (isChecked)
                {

                    if (checkedId == R.id.radio1){

                        checkedItem = 1111;

                    }else if (checkedId == R.id.radio2){

                        checkedItem = 2222;

                    }else if (checkedId == R.id.radio3){

                        checkedItem = 3333;

                    }else if (checkedId == R.id.radio4){

                        checkedItem = 4444;

                    } else if (checkedId == R.id.radio5){

                        checkedItem = 5555;

                    }

                        // Changes the textview's text to "Checked: example radiobutton text"
                    //Toast.makeText(VotingActivity.this, ""+checkedItem, Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    private void dialog(String title, String msg, final String cont){
        Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            builder = new Builder(VotingActivity.this, android.R.style.Theme_Material_Light_Dialog_Alert);
        } else {
            builder = new Builder(VotingActivity.this);
        }
        builder.setTitle(title)
                .setMessage(msg)
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // continue with delete

                        if (cont.equals("tryagain")){
                            Intent intent = new Intent(VotingActivity.this, CountDownActivity.class);
                            startActivity(intent);
                            finish();
                        }

                    }
                })
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

    private boolean validate(){
        if (checkedItem == 0 ){
            dialog("Choose candidate","You must choose some cadidate", "");
            return false;
        }else {
            return true;
        }
    }

    private String stamp, status;

    private class getUserDet extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {

            try {
                String link = "http://mvmiddle.co.nf/castvote.php";
                URL url = new URL(link);
                HttpURLConnection httpURLConnection = (HttpURLConnection)url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.10240 ");
                httpURLConnection.setRequestProperty("Cookie", "__test=2ad4957fd60a8b74775f11b309b4496a; expires=Friday, 1 January 2038 at 01:55:55; path=/");//other any other
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data = URLEncoder.encode("vote_stamp", "UTF-8")+"="+URLEncoder.encode(stamp, "UTF-8")+"&"+
                        URLEncoder.encode("vote_id", "UTF-8")+"="+URLEncoder.encode(""+checkedItem, "UTF-8");
                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader( new InputStreamReader(inputStream, "iso-8859-1"));
                String result = "";
                String line = "";
                while ((line=bufferedReader.readLine())!= null){
                    result += line;
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                System.out.println("5555555555555  "+result);
                status = result;
                System.out.println("\n5555555555555  "+status);

            } catch (MalformedURLException e) {
                System.out.println("55555555555 "+e.getMessage());

// TODO Auto-generated catch block
                e.printStackTrace();
            } catch (IOException e) {
                System.out.println("55555555555 "+e.getMessage());
// TODO Auto-generated catch block
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            DetailStore.setVoteStamp(stamp);
            DetailStore.setVoteId(""+checkedItem);

            progressDialog.dismiss();

            try{
                if (status.equals("0")){

                    Intent intent = new Intent(VotingActivity.this, CountDownActivity2.class);
                    startActivity(intent);
                    finish();

                }else {

                    dialog("Something went wrong", "Try again by clicking OK", "tryagain");

                }
            }catch (Exception e){

            }


        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            progressDialog = new ProgressDialog(VotingActivity.this);
            progressDialog.setCancelable(false);
            progressDialog.setMessage("Recording Vote...");

            progressDialog.show();

        }
    }

}
