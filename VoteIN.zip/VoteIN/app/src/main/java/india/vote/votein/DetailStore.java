package india.vote.votein;

public class DetailStore {

    private static String aadhaarid;
    private static String mobileid;
    private static String imeiid;
    private static String voteStamp;
    private static String voteId;

    public static String getAadhaarid() {
        return aadhaarid;
    }

    public static void setAadhaarid(String aadhaarid) {
        DetailStore.aadhaarid = aadhaarid;
    }

    public static String getImeiid() {
        return imeiid;
    }

    public static void setImeiid(String imeiid) {
        DetailStore.imeiid = imeiid;
    }

    public static String getMobileid() {
        return mobileid;
    }

    public static void setMobileid(String mobileid) {
        DetailStore.mobileid = mobileid;
    }

    public static String getVoteId() {
        return voteId;
    }

    public static String getVoteStamp() {
        return voteStamp;
    }

    public static void setVoteId(String voteId) {
        DetailStore.voteId = voteId;
    }

    public static void setVoteStamp(String voteStamp) {
        DetailStore.voteStamp = voteStamp;
    }
}
