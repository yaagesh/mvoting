package india.vote.votein;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.Image;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.zxing.client.android.Intents;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Text;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.text.AttributedCharacterIterator;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HttpsURLConnection;

public class ScanAadharActivity extends AppCompatActivity {

    private FloatingActionButton qrScanner;
    String uid, name, gender, yearOfBirth, careOf, villageTehsil, postOffice, district, state, postCode;
    TextView aadharNumber, aadharName, aadharGender, aadharYob, aadharAddress, aadharPincode;
    EditText phoneNuber, phoneNumberOTP;
    String codeSent, mac_address, imeiNum;
    private FirebaseAuth mAuth;
    private static final int PERMISSION_READ_STATE = 200;
    String address, status;
    String phone = "";
    private String[] values;
    ProgressDialog progressDialog;
    Button phoneNumberVerify;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan_aadhar);

        FirebaseApp.initializeApp(this);

        mAuth = FirebaseAuth.getInstance();

        qrScanner = (FloatingActionButton) findViewById(R.id.qr_scanner);
        aadharNumber = (TextView) findViewById(R.id.aadhaarNum);
        aadharName = (TextView) findViewById(R.id.aadhaarName);
        aadharGender = (TextView) findViewById(R.id.aadharGender);
        aadharAddress = (TextView) findViewById(R.id.aadharAddress);
        aadharPincode = (TextView) findViewById(R.id.aadharPincode);
        aadharYob = (TextView) findViewById(R.id.aadharYOB);
        phoneNuber = (EditText) findViewById(R.id.phoneNumber);
        phoneNumberOTP = (EditText) findViewById(R.id.phoneNumberOTP);
        phoneNumberOTP.setVisibility(View.GONE);
        phoneNumberVerify = (Button) findViewById(R.id.phoneNumberVerify);

        phoneNumberVerify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validate()) {
                    phoneNumberOTP.setVisibility(View.VISIBLE);
                    phone = "+91"+phoneNuber.getText().toString();
                    imeiNum = getDeviceId(ScanAadharActivity.this);
                    //sendVerificationCode();
                }
            }
        });

        progressDialog = new ProgressDialog(this);

        qrScanner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startScanner();
            }
        });

        startScanner();

    }

    private void verifySignInCode() {
        progressDialog.setMessage("Verifing Phone Number");
        progressDialog.show();
        //Toast.makeText(this, ""+imeiNum, Toast.LENGTH_SHORT).show();
        String code = phoneNumberOTP.getText().toString();
        new getUserDet().execute("");
        try{
            //PhoneAuthCredential credential = PhoneAuthProvider.getCredential(codeSent, code);
            //signInWithPhoneAuthCredential(credential);
        }catch (Exception e){

        }
    }

    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            //here you can open new activity
                            Toast.makeText(getApplicationContext(),
                                    "Verification Successfull", Toast.LENGTH_LONG).show();
                            new getUserDet().execute("");
                            //Toast.makeText(ScanAadharActivity.this, ""+status, Toast.LENGTH_SHORT).show();

                        } else {
                            if (task.getException() instanceof FirebaseAuthInvalidCredentialsException) {
                                progressDialog.dismiss();
                                dialog("Failed!!!","Incorrect Verification Code","");
                            }
                        }
                    }
                });
    }

    private void startScanner() {
        IntentIntegrator integrator = new IntentIntegrator(ScanAadharActivity.this);
        integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE_TYPES);
        integrator.setPrompt("\n\nScan your AADHAR QR Code");
        integrator.setCaptureActivity(QRscannerActivity.class);
        integrator.setCameraId(0);  // Use a specific camera of the device
        integrator.setBeepEnabled(false);
        integrator.setBarcodeImageEnabled(true);
        integrator.initiateScan();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            if (result.getContents() == null) {

                Toast.makeText(this, "Cancelled", Toast.LENGTH_LONG).show();
            } else {

                processScannedData(result.getContents());
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.navi, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }

        if (item.getItemId() == R.id.mybutton && validate() ) {
            //Toast.makeText(AttachCropSenseActivity.this, "Tick clicked", Toast.LENGTH_SHORT).show();
            WifiManager manager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            WifiInfo info = manager.getConnectionInfo();
            mac_address = info.getMacAddress();

            permitioReq();
            if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
            }

            System.out.println("5555555555555  " + mac_address);


        }else {
            dialog("Fields Empty","Fill all the fields and Verify your phone number","");
        }
        return super.onOptionsItemSelected(item);
    }

    public String getDeviceId(Context context) {
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
        }
        return telephonyManager.getDeviceId();
    }

    private boolean permitioReq(){
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_PHONE_STATE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.READ_PHONE_STATE}, PERMISSION_READ_STATE);
            // We do not have this permission. Let's ask the user
        }else {
            verifySignInCode();
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_READ_STATE: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show();

                    verifySignInCode();
                    // permission granted!
                    // you may now do the action that requires this permission
                } else {
                    dialog("With out Permission app will not work","Please allow application to access the device", "permi");
                    // permission denied
                }
                return;
            }

        }
    }

    protected void processScannedData(String scanData){
        Log.d("VoteIN",scanData);
        XmlPullParserFactory pullParserFactory;
        try {
            // init the parserfactory
            pullParserFactory = XmlPullParserFactory.newInstance();
            // get the parser
            XmlPullParser parser = pullParserFactory.newPullParser();
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
            parser.setInput(new StringReader(scanData));
            // parse the XML
            int eventType = parser.getEventType();
            while (eventType != XmlPullParser.END_DOCUMENT) {
                if(eventType == XmlPullParser.START_DOCUMENT) {
                    Log.d("VoteIN","Start document");
                } else if(eventType == XmlPullParser.START_TAG && DataAttributes.AADHAAR_DATA_TAG.equals(parser.getName())) {
                    // extract data from tag
                    //uid
                    uid = parser.getAttributeValue(null,DataAttributes.AADHAR_UID_ATTR);
                    aadharNumber.setText(uid);
                    //name
                    name = parser.getAttributeValue(null,DataAttributes.AADHAR_NAME_ATTR);
                    aadharName.setText(name);
                    //gender
                    gender = parser.getAttributeValue(null,DataAttributes.AADHAR_GENDER_ATTR);
                    aadharGender.setText(gender);
                    // year of birth
                    yearOfBirth = parser.getAttributeValue(null,DataAttributes.AADHAR_YOB_ATTR);
                    aadharYob.setText(yearOfBirth);
                    // care of
                    careOf = parser.getAttributeValue(null,DataAttributes.AADHAR_CO_ATTR);
                    address = ""+careOf;
                    // village Tehsil
                    villageTehsil = parser.getAttributeValue(null,DataAttributes.AADHAR_VTC_ATTR);
                    String house = parser.getAttributeValue(null,DataAttributes.AADHAR_HOUSE_ATTR);
                    String street = parser.getAttributeValue(null,DataAttributes.AADHAR_STREET_ATTR);
                    String lm = parser.getAttributeValue(null,DataAttributes.AADHAR_LM_ATTR);
                    address = address+", "+house+"\n"+street+", "+lm+"\n"+villageTehsil;
                    // Post Office
                    postOffice = parser.getAttributeValue(null,DataAttributes.AADHAR_PO_ATTR);
                    address = address+"\n"+postOffice;
                    // district
                    district = parser.getAttributeValue(null,DataAttributes.AADHAR_DIST_ATTR);
                    address = address+"\n"+district;
                    // state
                    state = parser.getAttributeValue(null,DataAttributes.AADHAR_STATE_ATTR);
                    address = address+"\n"+state;
                    aadharAddress.setText(address);
                    // Post Code
                    postCode = parser.getAttributeValue(null,DataAttributes.AADHAR_PC_ATTR);
                    aadharPincode.setText(postCode);

                } else if(eventType == XmlPullParser.END_TAG) {
                    Log.d("VoteIN","End tag "+parser.getName());
                } else if(eventType == XmlPullParser.TEXT) {
                    Log.d("VoteIN","Text "+parser.getText());
                }
                // update eventType
                eventType = parser.next();
            }
            // display the data on screen
            //displayScannedData();
        } catch (XmlPullParserException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void sendVerificationCode(){

        if(phone.isEmpty()){
            phoneNuber.setError("Phone number is required");
            phoneNuber.requestFocus();
            return;
        }

        if(phone.length() < 10 ){
            phoneNuber.setError("Please enter a valid phone");
            phoneNuber.requestFocus();
            return;
        }


        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                phone,        // Phone number to verify
                60,                 // Timeout duration
                TimeUnit.SECONDS,   // Unit of timeout
                this,               // Activity (for callback binding)
                mCallbacks);        // OnVerificationStateChangedCallbacks
    }

    PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

        @Override
        public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {
            Toast.makeText(ScanAadharActivity.this, "Verification Code Send", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onVerificationFailed(FirebaseException e) {
            phoneNumberOTP.setVisibility(View.GONE);
            progressDialog.hide();
            Toast.makeText(ScanAadharActivity.this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();
            dialog("Failed!!!",""+e.getMessage(),"");
        }

        @Override
        public void onCodeSent(String s, PhoneAuthProvider.ForceResendingToken forceResendingToken) {
            super.onCodeSent(s, forceResendingToken);

            codeSent = s;
        }
    };

    private boolean validate(){
        Boolean valid = true;

        if(aadharNumber.getText().toString().isEmpty()){
            aadharNumber.setError("Phone number is required");
            aadharNumber.requestFocus();
            valid=false;
        }
        if(aadharName.getText().toString().isEmpty()){
            aadharName.setError("Phone number is required");
            aadharName.requestFocus();
            valid=false;
        }
        if(aadharGender.getText().toString().isEmpty()){
            aadharGender.setError("Phone number is required");
            aadharGender.requestFocus();
            valid=false;
        }
        if(aadharYob.getText().toString().isEmpty()){
            aadharYob.setError("Phone number is required");
            aadharYob.requestFocus();
            valid=false;
        }
        if(aadharAddress.getText().toString().isEmpty()){
            aadharAddress.setError("Phone number is required");
            aadharAddress.requestFocus();
            valid=false;
        }
        if(aadharPincode.getText().toString().isEmpty()){
            aadharPincode.setError("Phone number is required");
            aadharPincode.requestFocus();
            valid=false;
        }
        if(phoneNuber.getText().toString().isEmpty()){
            phoneNuber.setError("Phone number is required");
            phoneNuber.requestFocus();
            valid=false;
        }

        return valid;
    }

    private void dialog(String title, String msg, final String state){
        AlertDialog.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            builder = new AlertDialog.Builder(ScanAadharActivity.this, android.R.style.Theme_Material_Light_Dialog_Alert);
        } else {
            builder = new AlertDialog.Builder(ScanAadharActivity.this);
        }
        builder.setTitle(title)
                .setMessage(msg)
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // continue with delete
                        if (state.equals("permi")){
                            permitioReq();
                        }else if (state.equals("register")){
                            new setUserDet().execute("");
                        }else if (state.equals("setPre")){
                            finish();
                        }else if (state.equals("OK")){
                            new getVerifiedUser().execute("");
                            //dialog("Application Under Development","Please come back later.\nRemaining application will be updated SOON!!!","preSet");
                        }else if (state.equals("preSet")){
                            Intent intent = new Intent(ScanAadharActivity.this, CountDownActivity.class);
                            startActivity(intent);
                            finish();
                        }

                    }
                })
                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // do nothing
                    }
                })
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

    @Override
    protected void onStop() {
        super.onStop();
        progressDialog.dismiss();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        progressDialog.dismiss();
    }

    private class getUserDet extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {

            try {
                String link = "http://mvoting.co.nf/checkaadhar.php";
                URL url = new URL(link);
                HttpURLConnection httpURLConnection = (HttpURLConnection)url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.10240 ");
                httpURLConnection.setRequestProperty("Cookie", "__test=2ad4957fd60a8b74775f11b309b4496a; expires=Friday, 1 January 2038 at 01:55:55; path=/");//other any other
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data = URLEncoder.encode("imei_addr", "UTF-8")+"="+URLEncoder.encode(imeiNum, "UTF-8")+"&"+
                        URLEncoder.encode("aadhar_id", "UTF-8")+"="+URLEncoder.encode(uid, "UTF-8")+"&"+
                        URLEncoder.encode("aadhar_name", "UTF-8")+"="+URLEncoder.encode(name, "UTF-8")+"&"+
                        URLEncoder.encode("aadhar_gender", "UTF-8")+"="+URLEncoder.encode(gender, "UTF-8")+"&"+
                        URLEncoder.encode("aadhar_dob", "UTF-8")+"="+URLEncoder.encode(yearOfBirth, "UTF-8")+"&"+
                        URLEncoder.encode("aadhar_address", "UTF-8")+"="+URLEncoder.encode(address, "UTF-8")+"&"+
                        URLEncoder.encode("aadhar_pincode", "UTF-8")+"="+URLEncoder.encode(postCode, "UTF-8")+"&"+
                        URLEncoder.encode("aadhar_phone", "UTF-8")+"="+URLEncoder.encode(phone, "UTF-8");
                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader( new InputStreamReader(inputStream, "iso-8859-1"));
                String result = "";
                String line = "";
                while ((line=bufferedReader.readLine())!= null){
                    result += line;
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                System.out.println("5555555555555  "+result);
                status = result;
                System.out.println("\n5555555555555  "+status);

            } catch (MalformedURLException e) {
                System.out.println("55555555555 "+e.getMessage());

// TODO Auto-generated catch block
                e.printStackTrace();
            } catch (IOException e) {
                System.out.println("55555555555 "+e.getMessage());
// TODO Auto-generated catch block
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.hide();
            System.out.println("\n5555555555555 22  "+status);
            try{
                if (status.equals("0")){
                    dialog("Device Not Registered","Do you want to register this device?", "register");
                }else if (status.equals(imeiNum)){
                   // dialog("Account already Registered","Deregister the old device and come back to register this device", "preSet");
                    Toast.makeText(ScanAadharActivity.this, "Device Verified", Toast.LENGTH_SHORT).show();
                    new getVerifiedUser().execute("");
                    //dialog("Application Under Development","Please come back later.\nRemaining application will be updated SOON!!!","preSet");
                }else if (!status.equals(imeiNum)){
                    dialog("Account already Registered","Deregister the old device and come back to register this device", "preSet");
                }else {
                    dialog("Something Went Wrong","Please tryagin later", "");
                }
            }catch (Exception e){
                System.out.println("555555555555  "+e.getMessage());
            }

        }
    }

    private class getVerifiedUser extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {

            try {
                String link = "http://mvoting.co.nf/verifyaccount.php";
                URL url = new URL(link);
                HttpURLConnection httpURLConnection = (HttpURLConnection)url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.10240 ");
                httpURLConnection.setRequestProperty("Cookie", "__test=2ad4957fd60a8b74775f11b309b4496a; expires=Friday, 1 January 2038 at 01:55:55; path=/");//other any other
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data = URLEncoder.encode("imei_addr", "UTF-8")+"="+URLEncoder.encode(imeiNum, "UTF-8")+"&"+
                        URLEncoder.encode("aadhar_id", "UTF-8")+"="+URLEncoder.encode(uid, "UTF-8")+"&"+
                        URLEncoder.encode("aadhar_name", "UTF-8")+"="+URLEncoder.encode(name, "UTF-8")+"&"+
                        URLEncoder.encode("aadhar_gender", "UTF-8")+"="+URLEncoder.encode(gender, "UTF-8")+"&"+
                        URLEncoder.encode("aadhar_dob", "UTF-8")+"="+URLEncoder.encode(yearOfBirth, "UTF-8")+"&"+
                        URLEncoder.encode("aadhar_address", "UTF-8")+"="+URLEncoder.encode(address, "UTF-8")+"&"+
                        URLEncoder.encode("aadhar_pincode", "UTF-8")+"="+URLEncoder.encode(postCode, "UTF-8")+"&"+
                        URLEncoder.encode("aadhar_phone", "UTF-8")+"="+URLEncoder.encode(phone, "UTF-8");
                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader( new InputStreamReader(inputStream, "iso-8859-1"));
                String result = "";
                String line = "";
                while ((line=bufferedReader.readLine())!= null){
                    result += line;
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                System.out.println("5555555555555  "+result);
                values = result.split(";");
                System.out.println("\n5555555555555  "+status);

            } catch (MalformedURLException e) {
                System.out.println("55555555555 "+e.getMessage());

// TODO Auto-generated catch block
                e.printStackTrace();
            } catch (IOException e) {
                System.out.println("55555555555 "+e.getMessage());
// TODO Auto-generated catch block
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.hide();
            System.out.println("\n5555555555555 22  "+status);
            try{
                if (values[0].equals("0")){
                    dialog("Dear User,","You are not verified yet. Please go to neaarby AADHAAR center for verification", "");
                }else {

                    System.out.println("5555555555555555   "+values[1]);

                    if (values[1].equals("0")){

                        dialog("Wait for your time!!!","You will receive a SMS on the particular day then you can login and vote your favorite", "setPre");

                    }else if (values[1].equals("1")) {

                        DetailStore.setAadhaarid(uid);
                        DetailStore.setImeiid(imeiNum);
                        DetailStore.setMobileid(phone.substring(1));

                        Intent intent = new Intent(ScanAadharActivity.this, CountDownActivity.class);
                        startActivity(intent);
                        finish();

                    }else if (values[1].equals("2")){

                        dialog("You are done!!!", "Your vote is already casted.", "setPre");

                    }

                }
            }catch (Exception e){
                System.out.println("555555555555  "+e.getMessage());
            }

        }
    }

    private class getTakeuserIn extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {

            try {
                String link = "http://mvoting.co.nf/checkaadhar.php";
                URL url = new URL(link);
                HttpURLConnection httpURLConnection = (HttpURLConnection)url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.10240 ");
                httpURLConnection.setRequestProperty("Cookie", "__test=2ad4957fd60a8b74775f11b309b4496a; expires=Friday, 1 January 2038 at 01:55:55; path=/");//other any other
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data = URLEncoder.encode("imei_addr", "UTF-8")+"="+URLEncoder.encode(imeiNum, "UTF-8")+"&"+
                        URLEncoder.encode("aadhar_id", "UTF-8")+"="+URLEncoder.encode(uid, "UTF-8")+"&"+
                        URLEncoder.encode("aadhar_name", "UTF-8")+"="+URLEncoder.encode(name, "UTF-8")+"&"+
                        URLEncoder.encode("aadhar_gender", "UTF-8")+"="+URLEncoder.encode(gender, "UTF-8")+"&"+
                        URLEncoder.encode("aadhar_dob", "UTF-8")+"="+URLEncoder.encode(yearOfBirth, "UTF-8")+"&"+
                        URLEncoder.encode("aadhar_address", "UTF-8")+"="+URLEncoder.encode(address, "UTF-8")+"&"+
                        URLEncoder.encode("aadhar_pincode", "UTF-8")+"="+URLEncoder.encode(postCode, "UTF-8")+"&"+
                        URLEncoder.encode("aadhar_phone", "UTF-8")+"="+URLEncoder.encode(phone, "UTF-8");
                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader( new InputStreamReader(inputStream, "iso-8859-1"));
                String result = "";
                String line = "";
                while ((line=bufferedReader.readLine())!= null){
                    result += line;
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                System.out.println("5555555555555  "+result);
                status = result;
                System.out.println("\n5555555555555  "+status);

            } catch (MalformedURLException e) {
                System.out.println("55555555555 "+e.getMessage());

// TODO Auto-generated catch block
                e.printStackTrace();
            } catch (IOException e) {
                System.out.println("55555555555 "+e.getMessage());
// TODO Auto-generated catch block
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.hide();
            System.out.println("\n5555555555555 22  "+status);
            try{
                if (status.equals("0")){
                    dialog("Wait for the day","You will be logged in when the day comes", "");
                }else {
                    dialog("Instruction","Don't close the application until you finish the voting, also make sure you have choosed the right person.", "preSet");
                }
            }catch (Exception e){
                System.out.println("555555555555  "+e.getMessage());
            }

        }
    }

    private class setUserDet extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {

            try {
                String link = "http://mvoting.co.nf/insertaadhar.php";
                URL url = new URL(link);
                HttpURLConnection httpURLConnection = (HttpURLConnection)url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.10240 ");
                httpURLConnection.setRequestProperty("Cookie", "__test=2ad4957fd60a8b74775f11b309b4496a; expires=Friday, 1 January 2038 at 01:55:55; path=/");//other any other
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data = URLEncoder.encode("imei_addr", "UTF-8")+"="+URLEncoder.encode(imeiNum, "UTF-8")+"&"+
                        URLEncoder.encode("aadhar_id", "UTF-8")+"="+URLEncoder.encode(uid, "UTF-8")+"&"+
                        URLEncoder.encode("aadhar_name", "UTF-8")+"="+URLEncoder.encode(name, "UTF-8")+"&"+
                        URLEncoder.encode("aadhar_gender", "UTF-8")+"="+URLEncoder.encode(gender, "UTF-8")+"&"+
                        URLEncoder.encode("aadhar_dob", "UTF-8")+"="+URLEncoder.encode(yearOfBirth, "UTF-8")+"&"+
                        URLEncoder.encode("aadhar_address", "UTF-8")+"="+URLEncoder.encode(address, "UTF-8")+"&"+
                        URLEncoder.encode("aadhar_pincode", "UTF-8")+"="+URLEncoder.encode(postCode, "UTF-8")+"&"+
                        URLEncoder.encode("aadhar_phone", "UTF-8")+"="+URLEncoder.encode(phone, "UTF-8");
                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader( new InputStreamReader(inputStream, "iso-8859-1"));
                String result = "";
                String line = "";
                while ((line=bufferedReader.readLine())!= null){
                    result += line;
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                System.out.println("5555555555555  "+result);
                status = result;
                System.out.println("\n5555555555555  "+status);

            } catch (MalformedURLException e) {
                System.out.println("55555555555 "+e.getMessage());

// TODO Auto-generated catch block
                e.printStackTrace();
            } catch (IOException e) {
                System.out.println("55555555555 "+e.getMessage());
// TODO Auto-generated catch block
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.hide();
            System.out.println("\n5555555555555 22  "+status);
            try{
                if (status.equals("0")) {
                    dialog("Device Registered", "You can use only this device to register your vote", "OK");
                }else if (status.equals("1")) {
                    dialog("Something Went Wrong", "Please tryagin later", "setPre");
                }
            }catch (Exception e){
                System.out.println("555555555555  "+e.getMessage());
            }

        }
    }

}
